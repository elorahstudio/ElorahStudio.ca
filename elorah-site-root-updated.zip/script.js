const header = document.querySelector('.site-header');
const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

function syncHeader(){ header.classList.toggle('scrolled', window.scrollY > 24); }
syncHeader();
window.addEventListener('scroll', syncHeader, {passive:true});

menuToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));

const io = new IntersectionObserver(entries => {
  entries.forEach(entry => { if(entry.isIntersecting){ entry.target.classList.add('visible'); io.unobserve(entry.target); } });
}, {threshold:.12});
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

const lightbox = document.querySelector('.lightbox');
const lightboxImg = lightbox.querySelector('img');
document.querySelectorAll('.gallery-item').forEach(item => item.addEventListener('click', () => {
  lightboxImg.src = item.dataset.src;
  lightbox.hidden = false;
  document.body.style.overflow = 'hidden';
}));
function closeLightbox(){ lightbox.hidden = true; lightboxImg.src=''; document.body.style.overflow=''; }
lightbox.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', e => { if(e.target === lightbox) closeLightbox(); });
document.addEventListener('keydown', e => { if(e.key === 'Escape' && !lightbox.hidden) closeLightbox(); });

document.getElementById('contactForm').addEventListener('submit', e => {
  e.preventDefault();
  const data = new FormData(e.currentTarget);
  const subject = `ELORAH — ${data.get('inquiry')}`;
  const body = `Name: ${data.get('name')}\nEmail: ${data.get('email')}\nInquiry: ${data.get('inquiry')}\n\n${data.get('message')}`;
  window.location.href = `mailto:info.elorah@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
});

document.getElementById('year').textContent = new Date().getFullYear();
