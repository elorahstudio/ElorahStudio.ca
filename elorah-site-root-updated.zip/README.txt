ELORAH WEBSITE — READY TO PUBLISH
==================================

This folder contains a complete responsive static website for ELORAH.
Open index.html in a browser to preview it.

FILES
- index.html       Main website
- styles.css       Design / mobile styles
- script.js        Menu, animations, gallery, email form
- assets/          ELORAH logo and fashion photography

CONTACT DETAILS CURRENTLY USED
Email: info.elorah@gmail.com
Instagram: @elorah__studio
Phone: +1 514 777 6755

FREE HOSTING OPTIONS
1. Cloudflare Pages
2. GitHub Pages
3. Netlify

All three can host this static site for free and support a custom domain.

CUSTOM DOMAIN
After uploading the site, your hosting provider will give you DNS records.
In GoDaddy, go to your domain > DNS > Manage DNS and replace/add the records
provided by your host. Do not change anything until the host gives you the
exact records for your domain.

The contact form does not require a paid backend. It opens the visitor's
email app with the inquiry addressed to info.elorah@gmail.com.
